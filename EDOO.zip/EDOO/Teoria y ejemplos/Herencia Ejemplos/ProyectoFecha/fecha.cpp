
#include "fecha.h"

Fecha::Fecha(int dia, int mes, int anyo) {
  _dia = dia;
  _mes = mes;
  _anyo = anyo;
}
