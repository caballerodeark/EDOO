#include <iostream>
#include <fstream>
#include <cmath>
#include <stdlib.h>
#include <sstream>

using namespace std;

class Robot
{
    int ID,x,y,
};