/********************************************************************/
/** Nom autor:   Guillem Perez Sanchez                             **/
/** Data:        30/09/22                                          **/
/** Descripcio:  Grup 1 - 4.                                       **/
/********************************************************************/

#include <iostream>
#include <stdlib.h>
using namespace std;

// DECLARACIO DE CONSTANTS


/************************ PROGRAMA PRINCIPAL ************************/

int main ()
{
    // DECLARACIO DE VARIABLES

    char N,M;
    int n;

    //SENTENCIES

    cout<<"n: "; cin>>n;
    cout<<"N: "; cin>>N;
    cout<<"M: "; cin>>M;

    


    return 0;
}